from decimal import Decimal

from rest_framework import serializers
from .models import (
    User, Artist, ArtistAuth, NotificationSetting, Song, Album, Genre, SubGenre, 
    Mood, Tag, Report, PlayConfiguration, BannerAd, AudioAd, PaymentTransaction, 
    DepositRequest, SearchSection, EventPlaylist, Playlist
)
from django.contrib.auth import get_user_model

User = get_user_model()


class RequireEnglishTranslationSerializerMixin:
    """Require explicit English copy for admin-authored visible text.

    This applies to create requests and to updates that touch either side of a
    translation pair. Unrelated partial updates remain backward compatible.
    """

    translation_pairs = ()

    def validate(self, attrs):
        attrs = super().validate(attrs)
        errors = {}
        is_create = self.instance is None
        for source_name, english_name in self.translation_pairs:
            if not is_create and source_name not in attrs and english_name not in attrs:
                continue
            source_value = attrs.get(source_name, getattr(self.instance, source_name, None))
            english_value = attrs.get(english_name, getattr(self.instance, english_name, None))
            if source_value and not str(english_value or "").strip():
                errors[english_name] = "Enter the real English equivalent; transliteration/Finglish is not accepted."
        if errors:
            raise serializers.ValidationError(errors)
        return attrs

class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'id', 'phone_number', 'first_name', 'last_name', 'email',
            'roles', 'is_active', 'is_staff', 'is_verified', 'date_joined',
            'plan', 'stream_quality', 'last_login_at', 'failed_login_attempts', 'locked_until'
        ]
        read_only_fields = ['id', 'date_joined', 'last_login_at']

class AdminEmployeeSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = User
        fields = [
            'id', 'phone_number', 'first_name', 'last_name', 'email',
            'roles', 'is_active', 'is_verified', 'date_joined',
            'permissions', 'password'
        ]
        read_only_fields = ['id', 'date_joined']

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = super().create(validated_data)
        if password:
            user.set_password(password)
            user.save()
        return user

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        user = super().update(instance, validated_data)
        if password:
            user.set_password(password)
            user.save()
        return user

class AdminArtistSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('name', 'name_en'), ('artistic_name', 'artistic_name_en'), ('city', 'city_en'), ('address', 'address_en'), ('bio', 'bio_en'))
    has_user = serializers.SerializerMethodField()
    user_phone = serializers.CharField(source='user.phone_number', read_only=True)

    class Meta:
        model = Artist
        fields = [
            'id', 'name', 'name_en', 'artistic_name', 'artistic_name_en', 'email', 'city', 'city_en', 'date_of_birth',
            'address', 'address_en', 'id_number', 'user', 'user_phone', 'bio', 'bio_en', 'profile_image',
            'banner_image', 'verified', 'created_at', 'has_user'
        ]
        read_only_fields = ['id', 'created_at']

    def get_has_user(self, obj):
        return obj.user is not None

class AdminArtistAuthSerializer(serializers.ModelSerializer):
    class Meta:
        model = ArtistAuth
        fields = [
            'id', 'user', 'auth_type', 'artist_claimed',
            'first_name', 'first_name_en', 'last_name', 'last_name_en',
            'stage_name', 'stage_name_en', 'birth_date', 'national_id',
            'phone_number', 'email', 'city', 'address',
            'biography', 'biography_en', 'profile_image', 'national_id_image',
            'status', 'is_verified', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, attrs):
        status_value = attrs.get('status', getattr(self.instance, 'status', ArtistAuth.STATUS_PENDING))
        verified = attrs.get('is_verified', getattr(self.instance, 'is_verified', False))
        auth_type = attrs.get('auth_type', getattr(self.instance, 'auth_type', ArtistAuth.AUTH_FRESH))
        user = attrs.get('user', getattr(self.instance, 'user', None))
        claimed = attrs.get('artist_claimed', getattr(self.instance, 'artist_claimed', None))
        if status_value == ArtistAuth.STATUS_ACCEPTED or verified:
            if not user:
                raise serializers.ValidationError({'user': 'Approval requires a linked user.'})
            if auth_type == ArtistAuth.AUTH_EXISTING:
                if not claimed:
                    raise serializers.ValidationError({'artist_claimed': 'Select the existing artist before approval.'})
                if claimed.user_id not in (None, user.pk):
                    raise serializers.ValidationError({'artist_claimed': 'This artist is linked to another user.'})
                if Artist.objects.filter(user=user).exclude(pk=claimed.pk).exists():
                    raise serializers.ValidationError({'user': 'This user is linked to another artist profile.'})
        return attrs

class AdminSongSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'), ('description', 'description_en'), ('lyrics', 'lyrics_en'), ('label', 'label_en'), ('credits', 'credits_en'))
    # We use FileField for uploads, but the model stores URLField
    audio_file_upload = serializers.FileField(write_only=True, required=False)
    cover_image_upload = serializers.ImageField(write_only=True, required=False)
    
    # Display fields
    artist_name = serializers.CharField(source='artist.name', read_only=True)
    album_title = serializers.CharField(source='album.title', read_only=True, allow_null=True)

    # Relationship details
    featured_artists = serializers.SerializerMethodField()
    featured_artist_ids = serializers.PrimaryKeyRelatedField(
        queryset=Artist.objects.all(),
        many=True,
        source='featured_artists',
        required=False,
        write_only=True
    )

    def get_featured_artists(self, obj):
        return [{'id': a.id, 'name': a.name, 'artistic_name': a.artistic_name} for a in obj.featured_artists.all()]

    # JSON fields as ListFields for better form-data handling
    producers = serializers.ListField(child=serializers.CharField(), required=False)
    producers_en = serializers.ListField(child=serializers.CharField(), required=False)
    composers = serializers.ListField(child=serializers.CharField(), required=False)
    composers_en = serializers.ListField(child=serializers.CharField(), required=False)
    lyricists = serializers.ListField(child=serializers.CharField(), required=False)
    lyricists_en = serializers.ListField(child=serializers.CharField(), required=False)

    class Meta:
        model = Song
        fields = [
            'id', 'title', 'title_en', 'artist', 'artist_name', 'featured_artists', 'featured_artist_ids', 'album', 'album_title',
            'is_single', 'album_disc_number', 'album_track_number', 'audio_file', 'converted_audio_url', 'cover_image', 'original_format',
            'duration_seconds', 'plays', 'status', 'release_date', 'language',
            'genres', 'sub_genres', 'moods', 'tags', 'description', 'description_en', 'lyrics', 'lyrics_en',
            'tempo', 'energy', 'danceability', 'valence', 'acousticness',
            'instrumentalness', 'live_performed', 'speechiness', 'label', 'label_en',
            'producers', 'producers_en', 'composers', 'composers_en', 'lyricists', 'lyricists_en', 'credits', 'credits_en', 'uploader',
            'created_at', 'updated_at', 'audio_file_upload', 'cover_image_upload'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'plays']


class AdminReportSerializer(serializers.ModelSerializer):
    user_phone = serializers.CharField(source='user.phone_number', read_only=True)
    song_title = serializers.CharField(source='song.title', read_only=True, allow_null=True)
    artist_name = serializers.CharField(source='artist.name', read_only=True, allow_null=True)
    reported_user_phone = serializers.CharField(source='reported_user.phone_number', read_only=True, allow_null=True)

    class Meta:
        model = Report
        fields = [
            'id', 'user', 'user_phone', 'song', 'song_title', 'artist', 'artist_name', 'reported_user', 'reported_user_phone',
            'text', 'has_reviewed', 'reviewed_at', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'user', 'song', 'artist', 'reported_user', 'created_at', 'updated_at']


class AdminAlbumSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'), ('description', 'description_en'))
    artist_name = serializers.CharField(source='artist.name', read_only=True)
    songs = AdminSongSerializer(many=True, read_only=True)
    cover_image_upload = serializers.ImageField(write_only=True, required=False)
    
    # For write operations
    genres = serializers.PrimaryKeyRelatedField(queryset=Genre.objects.all(), many=True, required=False)
    sub_genres = serializers.PrimaryKeyRelatedField(queryset=SubGenre.objects.all(), many=True, required=False)
    moods = serializers.PrimaryKeyRelatedField(queryset=Mood.objects.all(), many=True, required=False)

    class Meta:
        model = Album
        fields = [
            'id', 'title', 'title_en', 'artist', 'artist_name', 'cover_image', 'cover_image_upload',
            'release_date', 'description', 'description_en', 'genres', 'sub_genres', 'moods',
            'created_at', 'songs'
        ]
        read_only_fields = ['id', 'cover_image', 'created_at']


class AdminPlayConfigurationSerializer(serializers.ModelSerializer):
    per_normal_play_pay = serializers.DecimalField(source='free_play_worth', max_digits=12, decimal_places=8, min_value=0)
    per_premium_play_pay = serializers.DecimalField(source='premium_play_worth', max_digits=12, decimal_places=8, min_value=0)
    minimum_payout_amount = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        min_value=Decimal('0.01'),
    )

    class Meta:
        model = PlayConfiguration
        fields = [
            'premium_plan_price', 'per_normal_play_pay', 'per_premium_play_pay',
            'minimum_payout_amount', 'ad_frequency', 'updated_at'
        ]
        read_only_fields = ['updated_at']


class AdminBannerAdSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'),)
    image_upload = serializers.ImageField(write_only=True, required=False)

    class Meta:
        model = BannerAd
        fields = ['id', 'title', 'title_en', 'image', 'image_upload', 'navigate_link', 'is_active', 'created_at', 'updated_at']
        read_only_fields = ['id', 'image', 'created_at', 'updated_at']


class AdminAudioAdSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'),)
    audio_upload = serializers.FileField(write_only=True, required=False)
    image_cover_upload = serializers.ImageField(write_only=True, required=False)
    audio_url = serializers.CharField(required=False, allow_blank=True)
    image_cover = serializers.CharField(required=False, allow_blank=True, allow_null=True)

    class Meta:
        model = AudioAd
        fields = [
            'id', 'title', 'title_en', 'audio_url', 'audio_upload', 'image_cover', 'image_cover_upload',
            'navigate_link', 'duration', 'skippable_after', 'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class AdminPaymentTransactionSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('description', 'description_en'),)
    user_phone = serializers.CharField(source='user.phone_number', read_only=True)

    class Meta:
        model = PaymentTransaction
        fields = ['id', 'user', 'user_phone', 'transaction_id', 'amount', 'status', 'payment_method', 'description', 'description_en', 'created_at']
        read_only_fields = ['id', 'created_at']


class AdminDepositRequestSerializer(serializers.ModelSerializer):
    artist_name = serializers.CharField(source='artist.name', read_only=True)

    class Meta:
        model = DepositRequest
        fields = ['id', 'artist', 'artist_name', 'amount', 'status', 'transaction_id', 'submission_date', 'status_change_date', 'summary']
        read_only_fields = ['id', 'submission_date', 'status_change_date']


class AdminPlaylistSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'), ('description', 'description_en'))
    cover_image_upload = serializers.ImageField(write_only=True, required=False)
    
    class Meta:
        model = Playlist
        fields = ['id', 'title', 'title_en', 'description', 'description_en', 'cover_image', 'cover_image_upload', 'created_by', 'created_at']
        read_only_fields = ['id', 'cover_image', 'created_at']


class AdminSearchSectionSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'),)
    icon_logo_upload = serializers.ImageField(write_only=True, required=False)
    
    class Meta:
        model = SearchSection
        fields = [
            'id', 'type', 'title', 'title_en', 'icon_logo', 'icon_logo_upload', 'item_size',
            'songs', 'albums', 'playlists', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'icon_logo', 'created_at', 'updated_at']


class AdminEventPlaylistSerializer(RequireEnglishTranslationSerializerMixin, serializers.ModelSerializer):
    translation_pairs = (('title', 'title_en'),)
    cover_image_upload = serializers.ImageField(write_only=True, required=False)
    
    class Meta:
        model = EventPlaylist
        fields = ['id', 'title', 'title_en', 'time_of_day', 'cover_image', 'cover_image_upload', 'playlists', 'created_at', 'updated_at']
        read_only_fields = ['id', 'cover_image', 'created_at', 'updated_at']

